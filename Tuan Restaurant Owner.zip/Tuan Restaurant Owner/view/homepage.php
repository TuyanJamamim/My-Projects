
<!DOCTYPE html>


<html lang="en">
<head>
    <title>Homepage</title>
</head>


 <?php include('header.php')?>
<body>


    

        <p><br></p><p><br></p>
        <table align="center" border="8px" style="padding: 15px;">
            <tr>
                <td>
                    <h2 align="center">WELCOME</h2> 
                    <h2 align="center">TO</h2>
                    <h2 align="center">Food delivery Service</h2>
                </td>
            </tr>
        </table>

    
    <p><br></p><p><br></p>
    
</body>

<?php include('footer.php')?>

</html>

