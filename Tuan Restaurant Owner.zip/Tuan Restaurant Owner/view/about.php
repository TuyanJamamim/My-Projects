



<!DOCTYPE html>
<html>

 <?php include('header.php')?>

<style>

</style>

  <p><br></p><p><br></p>
        <table align="center" border="8px" style="padding: 15px;" id="about">
            <tr>
                <td>
                    <h3 align="center">‘Food delivery Service’ Since our modest beginnings in 2005 with a little space in Toronto’s stylish Yorkville locale, ‘Organization Name’ ‘s development has been enlivened with the energy to cook and serve solid, Indian-roused takeout food. </h3> 

                </td>
            </tr>
        </table>
<p><br></p><p><br></p>

<body>





</body>


  <?php include('footer.php')?>

  </html>