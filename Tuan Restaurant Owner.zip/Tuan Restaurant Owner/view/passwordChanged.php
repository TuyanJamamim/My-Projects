


<!DOCTYPE html>
<html>

 <?php include('header.php')?>



<p><br></p><p><br></p>
        <span > <b> <h1 align="center"><?php echo  "Password Changed Successfully  ";?></h1> </span>
<p><br></p><p><br></p>

<body>





</body>


  <?php include('footer.php')?>

  </html>