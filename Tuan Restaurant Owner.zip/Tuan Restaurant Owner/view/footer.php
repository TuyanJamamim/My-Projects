<?php

	echo "<hr/><p></p><p align=center><br>Copyright <span>&#169;</span>2022 Food delivery Service<br> tuan@gmail.com </p>";

?>
